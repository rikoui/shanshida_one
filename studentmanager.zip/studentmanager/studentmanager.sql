/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50631
Source Host           : localhost:3306
Source Database       : studentmanager

Target Server Type    : MYSQL
Target Server Version : 50631
File Encoding         : 65001

Date: 2018-08-13 10:16:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `A_ID` varchar(50) NOT NULL,
  `A_NAME` varchar(50) DEFAULT NULL,
  `A_ADMIN` varchar(20) DEFAULT NULL,
  `A_PWD` varchar(20) DEFAULT NULL,
  `A_TEL` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`A_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('000001', '学生管理员', 'admin', '123456', null);

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `S_ID` varchar(50) NOT NULL,
  `S_NUM` varchar(10) DEFAULT NULL,
  `S_NAME` varchar(20) DEFAULT NULL,
  `S_SEX` varchar(2) DEFAULT NULL,
  `S_AGE` int(3) DEFAULT NULL,
  `S_TEL` varchar(11) DEFAULT NULL,
  `S_CLASS` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`S_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('0CE1E6259EE248A08C2CDDC6089C492D', '004', '香蕉', '女', '20', '13586596523', '三年级二班');
INSERT INTO `student` VALUES ('12A460E1A84646E2B62C1108F30A4D13', '008', '航空', '男', '19', '18956325210', '三年级五班');
INSERT INTO `student` VALUES ('23791AAE90804E76AB6730194D8A62C2', '009', '过渡', '男', '21', '13656565632', '三年级八班');
INSERT INTO `student` VALUES ('43D1A4E6A22847A4B203CF489C6D29B5', '002', '橘子', '男', '20', '13300000000', '三年级二班');
INSERT INTO `student` VALUES ('6A0BDFF7A2554D59B35524123CC16D7E', '001', '苹果', '女', '19', '13200000000', '三年级二班');
INSERT INTO `student` VALUES ('8443CE1B33D5480092FD29E7A5DED568', '003', '石榴', '女', '19', '13625632569', '三年级五班');
INSERT INTO `student` VALUES ('B1D72406AE2E4371B1054A7E1D1A46EE', '005', '橙子', '男', '19', '13256356985', '三年级三班');
INSERT INTO `student` VALUES ('CF8CE236D8804151AAA753129C920C01', '010', '通过', '男', '21', '13656985641', '三年级八班');
INSERT INTO `student` VALUES ('DAEE0E74EB5147AEA6F89D274A76360D', '006', '回归', '男', '19', '13563258654', '三年级三班');
INSERT INTO `student` VALUES ('E55130EE03BC4E6CB452C7E34B2E1163', '007', '天赋', '女', '18', '18965235621', '三年级一班');
