package com.lixw.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;
import com.lixw.service.IStudentService;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Resource
	private IStudentService studentService;

	/**
	 * 跳转到学生列表页面
	 * @return
	 */
	@RequestMapping("/toStudentList.do")
	public String toStringList () {
		return "studentList";
	}
	/**
	 * 查询所有学生
	 * 
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/queryStudentList.do")
	public SSDDataTableBean<Map<String, Object>> queryStudentList(HttpServletRequest request) {
		return studentService.queryWeeklyByPage(request);
	}
	
	/**
	 * 新增学生
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addStudent.do")
	public SSDResultBean addStudent(HttpServletRequest request) {
		return studentService.addStudent(request);
	}
	
	/**
	 * 编辑学生
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/editStudent.do")
	public SSDResultBean editStudent(HttpServletRequest request) {
		return studentService.editStudent(request);
	}
	
	/**
	 * 删除学生
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/delStudent.do")
	public SSDResultBean delStudent(HttpServletRequest request) {
		return studentService.delStudent(request);
	}

}
