package com.lixw.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;

public interface IStudentService {

	/**
	 * 查询所有学生
	 * 
	 * @param request
	 * @return
	 */
	SSDDataTableBean<Map<String, Object>> queryWeeklyByPage(HttpServletRequest request);

	/**
	 * 新增学生
	 * 
	 * @param request
	 * @return
	 */
	public SSDResultBean addStudent(HttpServletRequest request);

	/**
	 * 编辑学生
	 * 
	 * @param request
	 * @return
	 */
	public SSDResultBean editStudent(HttpServletRequest request);

	/**
	 * 删除学生
	 * 
	 * @param request
	 * @return
	 */
	public SSDResultBean delStudent(HttpServletRequest request);

}
