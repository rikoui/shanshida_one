package com.lixw.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;
import com.lixw.dao.StudentCustomMapper;
import com.lixw.dao.StudentMapper;
import com.lixw.model.Student;
import com.lixw.model.StudentExample;
import com.lixw.service.IStudentService;
import com.lixw.utils.SSDPrimaryKeyUtil;

@Service("studentService")
public class StudentService extends BaseServiceImpl implements IStudentService {

	@Resource
	private StudentMapper studentMapper;
	@Resource
	private StudentCustomMapper studentCustomMapper;

	/**
	 * 查询所有学生
	 */
	@Override
	public SSDDataTableBean<Map<String, Object>> queryWeeklyByPage(HttpServletRequest request) {
		// 初始化分页参数
		initPageParameter(request);
		String sNum = request.getParameter("sNum");
		String sName = request.getParameter("sName");
		if (notNull(sNum)) {
			params.put("sNum", sNum);
		}
		if (notNull(sName)) {
			params.put("sName", sName);
		}
		List<Map<String, Object>> studentList = studentCustomMapper.queryStudentListByPage(params);

		return new SSDDataTableBean<>(pageUtil.getTotalCount(), studentList);
	}

	/**
	 * 新增学生
	 */
	@Override
	public SSDResultBean addStudent(HttpServletRequest request) {
		String sNum = request.getParameter("sNum");
		String sName = request.getParameter("sName");
		String sSex = request.getParameter("sSex");
		String sAge = request.getParameter("sAge");
		String sTel = request.getParameter("sTel");
		String sClass = request.getParameter("sClass");
		// 判断学号是否存在
		StudentExample studentExample = new StudentExample();
		studentExample.createCriteria().andSNumEqualTo(sNum);
		List<Student> studentList = studentMapper.selectByExample(studentExample);
		if (studentList != null && studentList.size() > 0) {
			return new SSDResultBean("1", "学号已经存在！", "学号已经存在！");
		}
		Student student = new Student();
		student.setsId(SSDPrimaryKeyUtil.getPrimaryKey(""));
		student.setsNum(sNum);
		student.setsName(sName);
		student.setsSex(sSex);
		student.setsAge(Integer.parseInt(sAge));
		student.setsTel(sTel);
		student.setsClass(sClass);
		int count = studentMapper.insertSelective(student);
		if (count > 0) {
			return new SSDResultBean("0", "", "新增学生成功！");
		}
		return new SSDResultBean("1", "新增学生失败！", "新增学生失败！");
	}

	/**
	 * 编辑学生
	 */
	@Override
	public SSDResultBean editStudent(HttpServletRequest request) {
		String sId = request.getParameter("sId");
		String sNum = request.getParameter("sNum");
		String sName = request.getParameter("sName");
		String sSex = request.getParameter("sSex");
		String sAge = request.getParameter("sAge");
		String sTel = request.getParameter("sTel");
		String sClass = request.getParameter("sClass");
		// 判断学号是否重复
		StudentExample studentExample = new StudentExample();
		studentExample.createCriteria().andSNumEqualTo(sNum);
		List<Student> studentList = studentMapper.selectByExample(studentExample);
		if (studentList != null && studentList.size() > 0) {
			String getsId = studentList.get(0).getsId();
			if (!getsId.equals(sId)) {
				return new SSDResultBean("1", "学号已经存在！", "学号已经存在！");
			}
		}

		Student student = studentMapper.selectByPrimaryKey(sId);
		student.setsNum(sNum);
		student.setsName(sName);
		student.setsSex(sSex);
		student.setsAge(Integer.parseInt(sAge));
		student.setsTel(sTel);
		student.setsClass(sClass);
		int count = studentMapper.updateByPrimaryKey(student);
		if (count > 0) {
			return new SSDResultBean("0", "", "编辑学生成功！");
		}
		return new SSDResultBean("1", "编辑学生失败！", "编辑学生失败！");
	}

	/**
	 * 删除学生
	 */
	@Override
	public SSDResultBean delStudent(HttpServletRequest request) {
		String sId = request.getParameter("sId");
		Student student = studentMapper.selectByPrimaryKey(sId);
		int count = studentMapper.deleteByPrimaryKey(sId);
		if (count > 0) {
			return new SSDResultBean("0", "", "删除学生【" + student.getsName() + "】成功！");
		}
		return new SSDResultBean("1", "删除学生" + student.getsName() + "失败！", "删除学生【" + student.getsName() + "】失败！");
	}

}
