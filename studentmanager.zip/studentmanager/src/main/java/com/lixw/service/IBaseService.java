package com.lixw.service;


/**
 * 业务层基础接口
 * @author lixw
 *
 */
public interface IBaseService {
	
}
