package com.lixw.dao;

import java.util.List;
import java.util.Map;

public interface StudentCustomMapper {

	List<Map<String, Object>> queryStudentListByPage(Map<String, Object> params);
}