/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.6.31-log : Database - bookmanager
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bookmanager` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bookmanager`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `A_ID` varchar(50) NOT NULL,
  `A_NAME` varchar(50) DEFAULT NULL,
  `A_ADMIN` varchar(20) DEFAULT NULL,
  `A_PWD` varchar(20) DEFAULT NULL,
  `A_TEL` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`A_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `admin` */

insert  into `admin`(`A_ID`,`A_NAME`,`A_ADMIN`,`A_PWD`,`A_TEL`) values ('000001','管理员','admin','123456',NULL);

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `book_id` varchar(50) NOT NULL COMMENT 'ID',
  `book_no` varchar(50) DEFAULT NULL COMMENT '图书编号',
  `book_code` varchar(50) DEFAULT NULL COMMENT '图书条码',
  `book_name` varchar(50) DEFAULT NULL COMMENT '图书名称',
  `book_type` varchar(10) DEFAULT NULL COMMENT '图书类型',
  `book_author` varchar(20) DEFAULT NULL COMMENT '图书作者',
  `book_cbs` varchar(50) DEFAULT NULL COMMENT '图书出版社',
  `book_price` decimal(16,2) DEFAULT NULL COMMENT '图书价格',
  `book_status` varchar(2) DEFAULT NULL COMMENT '图书状态，00：归还，01：借出',
  `book_num` int(2) DEFAULT NULL COMMENT '图书数量',
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `book` */

insert  into `book`(`book_id`,`book_no`,`book_code`,`book_name`,`book_type`,`book_author`,`book_cbs`,`book_price`,`book_status`,`book_num`) values ('3329ADFE15C64E948E284D9D2790E4BB','0002','000B','JAVA（中）','04','贾明','陕师大','100.25','00',3),('CA967B12569F4F94A8420B0F886A9859','0004','000D','编程思想','04','赵敏','陕师大','56.80','00',2),('CC0D6CBDD4E74C66BACA3EEA94F0ACBA','0001','000A','JAVA（上）','04','刘明','陕师大','125.50','00',2),('EA93F591FBB545D8A1E60560CC6D1D6F','0003','000C','JAVA（下）','04','王超','陕师大','125.25','00',4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
