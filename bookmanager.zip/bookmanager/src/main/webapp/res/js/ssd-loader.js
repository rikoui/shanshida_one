document.write('<link href="../res/js/easyui/css/default.css" rel="stylesheet" type="text/css" />');
document.write('<link rel="stylesheet" type="text/css" href="res/js/easyui/js/themes/default/easyui.css" />');
document.write('<link rel="stylesheet" type="text/css" href="res/js/easyui/js/themes/icon.css" />');
document.write('<link rel="stylesheet" type="text/css" href="../res/css/dmt.css" />');
document.write('<script type="text/javascript" src="res/js/easyui/js/jquery-1.4.2.min.js"></script>');
document.write('<script type="text/javascript" src="res/js/easyui/js/jquery.easyui.js"></script>');
document.write('<script type="text/javascript" src="res/js/dmt.js"></script>');
document.write('<script type="text/javascript" src="res/js/json2.js"></script>');    
document.write('<script type="text/javascript" src="res/js/ajaxfileupload.js"></script>');








