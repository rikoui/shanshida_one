package com.lixw.config;

import java.util.HashMap;
import java.util.Map;

/**
 * 系统参数类
 * 
 * @author lixw
 *
 */
public class EnumParameter {

	/**
	 * 图书状态参数
	 */
	public static Map<String, String> BOOK_STATUS = new HashMap<String, String>();
	
	/**
	 * 图书类型参数
	 */
	public static Map<String, String> BOOK_TYPE = new HashMap<String, String>();

	static {
		// 添加图书状态
		BOOK_STATUS.put("00", "归还");
		BOOK_STATUS.put("01", "借出");
		
		// 添加图书类型
		BOOK_TYPE.put("00", "马列主义、毛泽东思想");
		BOOK_TYPE.put("01", "哲学");
		BOOK_TYPE.put("02", "社会科学");
		BOOK_TYPE.put("03", "自然科学");
		BOOK_TYPE.put("04", "综合性图书");
	}

}
