package com.lixw.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;
import com.lixw.service.IBookService;

/**
 * 控制层
 * @author lixw
 *
 */
@Controller
@RequestMapping("/book")
public class BookController {
	
	@Resource
	private IBookService bookService;
	
	/**
	 * 跳转到图书列表页面
	 * @return
	 */
	@RequestMapping("/toBookList.do")
	public String toBookList() {
		return "bookList";
	}
	
	/**
	 * 查询图书列表
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/queryBookList.do")
	public SSDDataTableBean<Map<String, Object>> queryStudentList(HttpServletRequest request) {
		return bookService.queryBookListByPage(request);
	}
	
	/**
	 * 新增图书
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/addBook.do")
	public SSDResultBean addStudent(HttpServletRequest request) {
		return bookService.addBook(request);
	}
	
	/**
	 * 编辑图书
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/editBook.do")
	public SSDResultBean editBook(HttpServletRequest request) {
		return bookService.editBook(request);
	}
	
	/**
	 * 删除图书
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/delBook.do")
	public SSDResultBean delBook(HttpServletRequest request) {
		return bookService.delBook(request);
	}
	
}
