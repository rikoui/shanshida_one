package com.lixw.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lixw.bean.SSDResultBean;
import com.lixw.service.IAdminService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Resource
	private IAdminService adminService;
	
	/**
	 * 登录
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/login.do")
	public SSDResultBean login(HttpServletRequest request, HttpServletResponse response, Model model) {
		return adminService.login(request);
	}

	/**
	 * 获取当前登录用户的信息
	 * 
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getSession.do")
	public SSDResultBean getSession(HttpServletRequest request) {
		return adminService.getSession(request);
	}
	
	/**
	 * 退出
	 * 
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/logout.do")
	public SSDResultBean logout(HttpServletRequest request) {
		return adminService.logout(request);
	}
}
