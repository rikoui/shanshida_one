package com.lixw.model;

import java.util.ArrayList;
import java.util.List;

public class AdminExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AdminExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAIdIsNull() {
            addCriterion("A_ID is null");
            return (Criteria) this;
        }

        public Criteria andAIdIsNotNull() {
            addCriterion("A_ID is not null");
            return (Criteria) this;
        }

        public Criteria andAIdEqualTo(String value) {
            addCriterion("A_ID =", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdNotEqualTo(String value) {
            addCriterion("A_ID <>", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdGreaterThan(String value) {
            addCriterion("A_ID >", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdGreaterThanOrEqualTo(String value) {
            addCriterion("A_ID >=", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdLessThan(String value) {
            addCriterion("A_ID <", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdLessThanOrEqualTo(String value) {
            addCriterion("A_ID <=", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdLike(String value) {
            addCriterion("A_ID like", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdNotLike(String value) {
            addCriterion("A_ID not like", value, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdIn(List<String> values) {
            addCriterion("A_ID in", values, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdNotIn(List<String> values) {
            addCriterion("A_ID not in", values, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdBetween(String value1, String value2) {
            addCriterion("A_ID between", value1, value2, "aId");
            return (Criteria) this;
        }

        public Criteria andAIdNotBetween(String value1, String value2) {
            addCriterion("A_ID not between", value1, value2, "aId");
            return (Criteria) this;
        }

        public Criteria andANameIsNull() {
            addCriterion("A_NAME is null");
            return (Criteria) this;
        }

        public Criteria andANameIsNotNull() {
            addCriterion("A_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andANameEqualTo(String value) {
            addCriterion("A_NAME =", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameNotEqualTo(String value) {
            addCriterion("A_NAME <>", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameGreaterThan(String value) {
            addCriterion("A_NAME >", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameGreaterThanOrEqualTo(String value) {
            addCriterion("A_NAME >=", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameLessThan(String value) {
            addCriterion("A_NAME <", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameLessThanOrEqualTo(String value) {
            addCriterion("A_NAME <=", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameLike(String value) {
            addCriterion("A_NAME like", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameNotLike(String value) {
            addCriterion("A_NAME not like", value, "aName");
            return (Criteria) this;
        }

        public Criteria andANameIn(List<String> values) {
            addCriterion("A_NAME in", values, "aName");
            return (Criteria) this;
        }

        public Criteria andANameNotIn(List<String> values) {
            addCriterion("A_NAME not in", values, "aName");
            return (Criteria) this;
        }

        public Criteria andANameBetween(String value1, String value2) {
            addCriterion("A_NAME between", value1, value2, "aName");
            return (Criteria) this;
        }

        public Criteria andANameNotBetween(String value1, String value2) {
            addCriterion("A_NAME not between", value1, value2, "aName");
            return (Criteria) this;
        }

        public Criteria andAAdminIsNull() {
            addCriterion("A_ADMIN is null");
            return (Criteria) this;
        }

        public Criteria andAAdminIsNotNull() {
            addCriterion("A_ADMIN is not null");
            return (Criteria) this;
        }

        public Criteria andAAdminEqualTo(String value) {
            addCriterion("A_ADMIN =", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminNotEqualTo(String value) {
            addCriterion("A_ADMIN <>", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminGreaterThan(String value) {
            addCriterion("A_ADMIN >", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminGreaterThanOrEqualTo(String value) {
            addCriterion("A_ADMIN >=", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminLessThan(String value) {
            addCriterion("A_ADMIN <", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminLessThanOrEqualTo(String value) {
            addCriterion("A_ADMIN <=", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminLike(String value) {
            addCriterion("A_ADMIN like", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminNotLike(String value) {
            addCriterion("A_ADMIN not like", value, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminIn(List<String> values) {
            addCriterion("A_ADMIN in", values, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminNotIn(List<String> values) {
            addCriterion("A_ADMIN not in", values, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminBetween(String value1, String value2) {
            addCriterion("A_ADMIN between", value1, value2, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAAdminNotBetween(String value1, String value2) {
            addCriterion("A_ADMIN not between", value1, value2, "aAdmin");
            return (Criteria) this;
        }

        public Criteria andAPwdIsNull() {
            addCriterion("A_PWD is null");
            return (Criteria) this;
        }

        public Criteria andAPwdIsNotNull() {
            addCriterion("A_PWD is not null");
            return (Criteria) this;
        }

        public Criteria andAPwdEqualTo(String value) {
            addCriterion("A_PWD =", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdNotEqualTo(String value) {
            addCriterion("A_PWD <>", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdGreaterThan(String value) {
            addCriterion("A_PWD >", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdGreaterThanOrEqualTo(String value) {
            addCriterion("A_PWD >=", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdLessThan(String value) {
            addCriterion("A_PWD <", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdLessThanOrEqualTo(String value) {
            addCriterion("A_PWD <=", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdLike(String value) {
            addCriterion("A_PWD like", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdNotLike(String value) {
            addCriterion("A_PWD not like", value, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdIn(List<String> values) {
            addCriterion("A_PWD in", values, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdNotIn(List<String> values) {
            addCriterion("A_PWD not in", values, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdBetween(String value1, String value2) {
            addCriterion("A_PWD between", value1, value2, "aPwd");
            return (Criteria) this;
        }

        public Criteria andAPwdNotBetween(String value1, String value2) {
            addCriterion("A_PWD not between", value1, value2, "aPwd");
            return (Criteria) this;
        }

        public Criteria andATelIsNull() {
            addCriterion("A_TEL is null");
            return (Criteria) this;
        }

        public Criteria andATelIsNotNull() {
            addCriterion("A_TEL is not null");
            return (Criteria) this;
        }

        public Criteria andATelEqualTo(String value) {
            addCriterion("A_TEL =", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelNotEqualTo(String value) {
            addCriterion("A_TEL <>", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelGreaterThan(String value) {
            addCriterion("A_TEL >", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelGreaterThanOrEqualTo(String value) {
            addCriterion("A_TEL >=", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelLessThan(String value) {
            addCriterion("A_TEL <", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelLessThanOrEqualTo(String value) {
            addCriterion("A_TEL <=", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelLike(String value) {
            addCriterion("A_TEL like", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelNotLike(String value) {
            addCriterion("A_TEL not like", value, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelIn(List<String> values) {
            addCriterion("A_TEL in", values, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelNotIn(List<String> values) {
            addCriterion("A_TEL not in", values, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelBetween(String value1, String value2) {
            addCriterion("A_TEL between", value1, value2, "aTel");
            return (Criteria) this;
        }

        public Criteria andATelNotBetween(String value1, String value2) {
            addCriterion("A_TEL not between", value1, value2, "aTel");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}