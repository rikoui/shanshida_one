package com.lixw.model;

public class Admin {
    private String aId;

    private String aName;

    private String aAdmin;

    private String aPwd;

    private String aTel;

    public String getaId() {
        return aId;
    }

    public void setaId(String aId) {
        this.aId = aId == null ? null : aId.trim();
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName == null ? null : aName.trim();
    }

    public String getaAdmin() {
        return aAdmin;
    }

    public void setaAdmin(String aAdmin) {
        this.aAdmin = aAdmin == null ? null : aAdmin.trim();
    }

    public String getaPwd() {
        return aPwd;
    }

    public void setaPwd(String aPwd) {
        this.aPwd = aPwd == null ? null : aPwd.trim();
    }

    public String getaTel() {
        return aTel;
    }

    public void setaTel(String aTel) {
        this.aTel = aTel == null ? null : aTel.trim();
    }
}