package com.lixw.bean;

import java.util.List;
/**
 * 用于返回表格数据
 * @author lixw
 *
 * @param <T>
 */
public class SSDDataTableBean<T> {
	//数据的总条数
	private int total;
	//返回的数据集合
	private List<T> rows;
	
	public SSDDataTableBean(){}
	
	public SSDDataTableBean(int total,List<T> rows){
		this.total = total;
		this.rows = rows;
	}
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public List<T> getRows() {
		return rows;
	}
	public void setRows(List<T> rows) {
		this.rows = rows;
	}
	
	
}
