package com.lixw.service;

import javax.servlet.http.HttpServletRequest;

import com.lixw.bean.SSDResultBean;

public interface IAdminService {

	/**
	 * 登录
	 * @param request
	 * @return
	 */
	public SSDResultBean login(HttpServletRequest request);

	/**
	 * 退出
	 * @param request
	 * @return
	 */
	public SSDResultBean logout(HttpServletRequest request);

	/**
	 * 获取当前登录用户的信息
	 * @param request
	 * @return
	 */
	public SSDResultBean getSession(HttpServletRequest request);
}
