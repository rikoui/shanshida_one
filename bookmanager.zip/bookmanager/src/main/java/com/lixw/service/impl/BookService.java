package com.lixw.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;
import com.lixw.config.EnumParameter;
import com.lixw.dao.BookCustomMapper;
import com.lixw.dao.BookMapper;
import com.lixw.model.Book;
import com.lixw.model.BookExample;
import com.lixw.service.IBookService;
import com.lixw.utils.ParameterUtil;
import com.lixw.utils.SSDPrimaryKeyUtil;
import com.lixw.utils.SSDSqlTransferUtil;

/**
 * 业务层
 * @author lixw
 *
 */
@Service("bookService")
public class BookService  extends BaseServiceImpl implements IBookService{
	
	@Resource
	private BookCustomMapper bookCustomMapper;
	@Resource
	private BookMapper bookMapper;

	@Override
	public SSDDataTableBean<Map<String, Object>> queryBookListByPage(HttpServletRequest request) {
		// 初始化分页参数
		initPageParameter(request);
		// 获取编号
		String bookNo = request.getParameter("bookNo");
		// 获取书名
		String bookName = request.getParameter("bookName");
		// 获取作者
		String bookAuthor = request.getParameter("bookAuthor");
		// 获取状态
		String bookStatus = request.getParameter("bookStatus");
		
		if (notNull(bookNo)) {
			params.put("bookNo", bookNo);
		}
		if (notNull(bookName)) {
			params.put("bookName", SSDSqlTransferUtil.transfer(bookName));
		}
		if (notNull(bookAuthor)) {
			params.put("bookAuthor", SSDSqlTransferUtil.transfer(bookAuthor));
		}
		if (notNull(bookStatus)) {
			params.put("bookStatus", bookStatus);
		}
		
		List<Map<String, Object>> bookList = bookCustomMapper.queryBookListByPage(params);
		
		// 翻译图书状态
		ParameterUtil.parseParam(bookList, "bookStatus", "bookStatusCopy", EnumParameter.BOOK_STATUS);
		// 翻译图书类型
		ParameterUtil.parseParam(bookList, "bookType", "bookTypeCopy", EnumParameter.BOOK_TYPE);
		return new SSDDataTableBean<>(pageUtil.getTotalCount(), bookList);
	}

	/**
	 * 新增图书
	 */
	@Override
	public SSDResultBean addBook(HttpServletRequest request) {
		// 获取编号
		String bookNo = request.getParameter("bookNo");
		// 获取条码
		String bookCode = request.getParameter("bookCode");
		// 获取书名
		String bookName = request.getParameter("bookName");
		// 获取类型
		String bookType = request.getParameter("bookType");
		// 获取作者
		String bookAuthor = request.getParameter("bookAuthor");
		// 获取出版社
		String bookCbs = request.getParameter("bookCbs");
		// 获取价格
		String bookPrice = request.getParameter("bookPrice");
		// 获取状态
		String bookStatus = request.getParameter("bookStatus");
		// 获取数量
		String bookNum = request.getParameter("bookNum");
		// 编号不能重复
		BookExample bookExample = new BookExample();
		bookExample.createCriteria().andBookNoEqualTo(bookNo);
		List<Book> bookByNo = bookMapper.selectByExample(bookExample);
		if (bookByNo != null && bookByNo.size() > 0) {
			return new SSDResultBean("1", "编号已经存在！", "");
		}
		// 条码不能重复
		bookExample.clear();
		bookExample.createCriteria().andBookCodeEqualTo(bookCode);
		List<Book> bookByCode = bookMapper.selectByExample(bookExample);
		if (bookByCode != null && bookByCode.size() > 0) {
			return new SSDResultBean("1", "条码已经存在！", "");
		}
		Book book = new Book();
		book.setBookId(SSDPrimaryKeyUtil.getPrimaryKey(""));
		book.setBookNo(bookNo);
		book.setBookCode(bookCode);
		book.setBookName(bookName);
		book.setBookType(bookType);
		book.setBookAuthor(bookAuthor);
		book.setBookCbs(bookCbs);
		book.setBookPrice(new BigDecimal(bookPrice));
		book.setBookStatus(bookStatus);
		book.setBookNum(Integer.parseInt(bookNum));
		bookMapper.insertSelective(book);
		return new SSDResultBean("0", "", "添加图书【" + bookName + "】成功！");
	}

	/**
	 * 编辑图书
	 */
	@Override
	public SSDResultBean editBook(HttpServletRequest request) {
		// 获取ID
		String bookId = request.getParameter("bookId");
		// 获取编号
		String bookNo = request.getParameter("bookNo");
		// 获取条码
		String bookCode = request.getParameter("bookCode");
		// 获取书名
		String bookName = request.getParameter("bookName");
		// 获取类型
		String bookType = request.getParameter("bookType");
		// 获取作者
		String bookAuthor = request.getParameter("bookAuthor");
		// 获取出版社
		String bookCbs = request.getParameter("bookCbs");
		// 获取价格
		String bookPrice = request.getParameter("bookPrice");
		// 获取状态
		String bookStatus = request.getParameter("bookStatus");
		// 获取数量
		String bookNum = request.getParameter("bookNum");
		// 编号不能重复
		BookExample bookExample = new BookExample();
		bookExample.createCriteria().andBookNoEqualTo(bookNo);
		List<Book> bookByNo = bookMapper.selectByExample(bookExample);
		if (bookByNo != null && bookByNo.size() > 0) {
			for (Book book : bookByNo) {
				if (!bookId.equals(book.getBookId())) {
					return new SSDResultBean("1", "编号已经存在！", "");
				}
			}
		}
		// 条码不能重复
		bookExample.clear();
		bookExample.createCriteria().andBookCodeEqualTo(bookCode);
		List<Book> bookByCode = bookMapper.selectByExample(bookExample);
		if (bookByCode != null && bookByCode.size() > 0) {
			for (Book book : bookByCode) {
				if (!bookId.equals(book.getBookId())) {
					return new SSDResultBean("1", "条码已经存在！", "");
				}
			}
		}
		Book book = new Book();
		book.setBookId(bookId);
		book.setBookNo(bookNo);
		book.setBookCode(bookCode);
		book.setBookName(bookName);
		book.setBookType(bookType);
		book.setBookAuthor(bookAuthor);
		book.setBookCbs(bookCbs);
		book.setBookPrice(new BigDecimal(bookPrice));
		book.setBookStatus(bookStatus);
		book.setBookNum(Integer.parseInt(bookNum));
		bookMapper.updateByPrimaryKeySelective(book);
		return new SSDResultBean("0", "", "编辑图书【" + bookName + "】成功！");
	}

	/**
	 * 删除图书
	 */
	@Override
	public SSDResultBean delBook(HttpServletRequest request) {
		// 获取ID
		String bookId = request.getParameter("bookId");
		Book book = bookMapper.selectByPrimaryKey(bookId);
		if (!"00".equals(book.getBookStatus())) {
			return new SSDResultBean("1", "图书未归还，不能删除", "");
		}
		bookMapper.deleteByPrimaryKey(bookId);
		return new SSDResultBean("0", "", "删除图书【" + book.getBookName() + "】成功！");
	}

}
