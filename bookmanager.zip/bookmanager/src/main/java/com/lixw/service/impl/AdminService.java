package com.lixw.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.lixw.bean.SSDResultBean;
import com.lixw.dao.AdminMapper;
import com.lixw.model.Admin;
import com.lixw.model.AdminExample;
import com.lixw.service.IAdminService;

@Service("adminService")
public class AdminService extends BaseServiceImpl implements IAdminService {

	@Resource
	private AdminMapper adminMapper;

	/**
	 * 登录
	 * 
	 * @param request
	 * @return
	 */
	@Override
	public SSDResultBean login(HttpServletRequest request) {
		String account = request.getParameter("account");
		String password = request.getParameter("password");

		AdminExample adminExample = new AdminExample();
		adminExample.createCriteria().andAAdminEqualTo(account);
		List<Admin> adminList = adminMapper.selectByExample(adminExample);
		if (adminList == null || adminList.size() == 0) {
			// 用户不存在
			return new SSDResultBean("1", "账户不存在", "账户不存在");
		}

		// 判断密码是否正确
		Admin admin = adminList.get(0);
		// 获取密码
		String aPwd = admin.getaPwd();
		if (!password.equals(aPwd)) {
			// 登录失败
			return new SSDResultBean("1", "账户或密码不正确", "账户或密码不正确");
		}

		request.getSession().setAttribute("adminSession", adminList.get(0));
		return new SSDResultBean("0", "登录成功", "登录成功");
	}

	/**
	 * 退出
	 */
	@Override
	public SSDResultBean logout(HttpServletRequest request) {
		request.getSession().removeAttribute("adminSession");
		return new SSDResultBean("0", "", "");
	}

	/**
	 * 获取当前登录用户的信息
	 */
	@Override
	public SSDResultBean getSession(HttpServletRequest request) {
		Admin admin = (Admin) request.getSession().getAttribute("adminSession");
		return new SSDResultBean("0", "", admin);
	}

}
