package com.lixw.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lixw.bean.SSDDataTableBean;
import com.lixw.bean.SSDResultBean;

public interface IBookService {

	SSDDataTableBean<Map<String, Object>> queryBookListByPage(HttpServletRequest request);

	SSDResultBean addBook(HttpServletRequest request);

	SSDResultBean editBook(HttpServletRequest request);

	SSDResultBean delBook(HttpServletRequest request);

}
