package com.lixw.utils;

import java.util.List;
import java.util.Map;

/**
 * 参数翻译工具
 * 
 * @author lixw
 *
 */
public class ParameterUtil {

	/**
	 * 列表参数解析
	 * 
	 * @param dataList
	 *            数据列表
	 * @param key
	 *            需要转换的key
	 * @param copyKey
	 *            转换之后的key
	 * @param paramMap
	 *            转换数据集
	 */
	public static void parseParam(List<Map<String, Object>> dataList, String key, String copyKey,
			Map<String, String> paramMap) {
		for (int i = 0; i < dataList.size(); i++) {
			Map<String, Object> data = dataList.get(i);
			String value = (String) data.get(key);
			for (String dataKey : paramMap.keySet()) {
				if (dataKey.equals(value)) {
					String copyValue = paramMap.get(dataKey);
					dataList.get(i).put(copyKey, copyValue);
				}
			}
		}
	}

}
