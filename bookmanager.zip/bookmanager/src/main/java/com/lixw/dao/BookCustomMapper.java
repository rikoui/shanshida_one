package com.lixw.dao;

import java.util.List;
import java.util.Map;

public interface BookCustomMapper {

	List<Map<String, Object>> queryBookListByPage(Map<String, Object> params);
}